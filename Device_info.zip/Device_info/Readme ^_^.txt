sql_conn: has the info about the database you created, I worked with the one in GNS3. Just follow S12 to get everything in place

sql_ip: Has the ip management of each router, so it directly pings it to check the connection before gathering the information

sql_ssh: has the required information to access the routers via ssh 
sql_device: gathers the output of the program :)

To run the file: python NetMonSQL.py sql_ip.txt sql_ssh.txt sql_conn.txt 

ALL THE BEST :) :) 

PS: If there is any error in the file, an log_error file will be generated to check the error